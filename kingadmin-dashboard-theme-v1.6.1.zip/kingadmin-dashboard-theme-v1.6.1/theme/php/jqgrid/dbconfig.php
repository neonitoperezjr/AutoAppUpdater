<?php

$DB_HOST = 'localhost';
$DB_NAME = 'dashboard_demo';
$DB_USERNAME = 'root';
$DB_PASSWORD = 'root';

?>